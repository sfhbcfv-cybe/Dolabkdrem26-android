package com.dolabk.dream26

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject

private val Gold = Color(0xFFFFD000)
private val Red = Color(0xFFE53935)
private val Bg = Color(0xFF090909)
private val Panel = Color(0xFF1A1713)
private val Muted = Color(0xFFBDBDBD)

private data class Kit(val name: String, val url: String)
private data class Team(val name: String, val logo: String, val kits: List<Kit>)
private data class League(val id: String, val name: String, val icon: String, val teams: List<Team>, val empty: Boolean)
private data class Country(val name: String, val flag: String, val logo: String, val kits: List<Kit>, val subcountries: List<Country>)
private data class Favorite(val name: String, val url: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val leagues = loadLeagues()
        val countries = loadCountries()
        val aliases = loadAliases()
        setContent { DolabkApp(leagues, countries, aliases) }
    }

    private fun asset(name: String) = assets.open(name).bufferedReader().use { it.readText() }
    private fun loadAliases(): Map<String, List<String>> {
        val obj = JSONObject(asset("aliases.json")); val out = mutableMapOf<String, List<String>>()
        obj.keys().forEach { k -> val a = obj.getJSONArray(k); out[k] = (0 until a.length()).map { a.getString(it) } }
        return out
    }
    private fun loadLeagues(): List<League> {
        val a = JSONArray(asset("leagues.json")); return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val teamsA = o.optJSONArray("teams") ?: JSONArray()
            League(o.optString("id"), o.optString("name"), o.optString("icon"), (0 until teamsA.length()).map { j ->
                val t = teamsA.getJSONObject(j); Team(t.optString("name"), t.optString("logo"), parseKits(t.optJSONArray("kits")))
            }, o.optBoolean("empty"))
        }
    }
    private fun loadCountries(): List<Country> {
        val a = JSONArray(asset("countries.json")); return (0 until a.length()).map { parseCountry(a.getJSONObject(it)) }
    }
    private fun parseCountry(o: JSONObject): Country {
        val sub = o.optJSONArray("subcountries") ?: JSONArray()
        return Country(o.optString("name"), o.optString("flag"), o.optString("logo"), parseKits(o.optJSONArray("kits")), (0 until sub.length()).map { parseCountry(sub.getJSONObject(it)) })
    }
    private fun parseKits(a: JSONArray?): List<Kit> {
        if (a == null) return emptyList()
        return (0 until a.length()).mapNotNull { i -> val item = a.optJSONArray(i) ?: return@mapNotNull null; if (item.length() < 2) null else Kit(item.optString(0), item.optString(1)) }
    }
}

@Composable
private fun DolabkApp(leagues: List<League>, countries: List<Country>, aliases: Map<String, List<String>>) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val prefs = remember { context.getSharedPreferences("dolabk_native", 0) }
    val favorites = remember { mutableStateListOf<Favorite>().apply {
        val a = runCatching { JSONArray(prefs.getString("favorites", "[]")) }.getOrElse { JSONArray() }
        for (i in 0 until a.length()) { val o = a.optJSONObject(i) ?: continue; add(Favorite(o.optString("name"), o.optString("url"))) }
    } }
    fun persist() { val a = JSONArray(); favorites.forEach { a.put(JSONObject().put("name", it.name).put("url", it.url)) }; prefs.edit().putString("favorites", a.toString()).apply() }
    var page by remember { mutableStateOf("home") }
    var search by remember { mutableStateOf("") }
    var selectedLeague by remember { mutableStateOf<League?>(null) }
    var selectedTeam by remember { mutableStateOf<Team?>(null) }
    var selectedCountry by remember { mutableStateOf<Country?>(null) }
    var parentPage by remember { mutableStateOf("home") }

    fun norm(s: String): String = s.lowercase().replace(Regex("[ً-ْٰـ]"), "").replace(Regex("[أإآ]"), "ا").replace("ى", "ي").replace("ة", "ه").replace("ؤ", "و").replace("ئ", "ي").replace(Regex("[^ء-يa-z0-9]+"), " ").trim()
    fun matches(name: String, q: String): Boolean {
        if (q.isBlank()) return true
        val nq = norm(q); val options = listOf(name) + aliases[name].orEmpty()
        return options.any { norm(it).contains(nq) || nq.contains(norm(it)) }
    }
    fun showUrl(url: String) { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }.onFailure { Toast.makeText(context, "تعذر فتح الرابط", Toast.LENGTH_SHORT).show() } }
    fun toggleFavorite(item: Favorite) {
        val old = favorites.indexOfFirst { it.url == item.url }
        if (old >= 0) favorites.removeAt(old) else favorites.add(item)
        persist()
    }
    fun isFavorite(url: String) = favorites.any { it.url == url }
    fun back() {
        when (page) {
            "team" -> { page = "league"; selectedTeam = null }
            "league" -> { page = "home"; selectedLeague = null }
            "countryDetail" -> { page = "countries"; selectedCountry = null }
            "favorites", "maker" -> page = "dolabak"
            else -> page = "home"
        }
    }
    BackHandler(page != "home") { back() }

    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, secondary = Red, background = Bg, surface = Panel)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF14110D), contentColor = Gold) {
                NavigationBarItem(selected = page == "home" || page == "league" || page == "team", onClick = { page = "home"; search = "" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
                NavigationBarItem(selected = page == "countries" || page == "countryDetail", onClick = { page = "countries"; search = "" }, icon = { Icon(Icons.Default.Public, null) }, label = { Text("المنتخبات") })
                NavigationBarItem(selected = page in listOf("dolabak", "favorites", "maker"), onClick = { page = "dolabak" }, icon = { Icon(Icons.Default.Favorite, null) }, label = { Text("دولابك") })
                NavigationBarItem(selected = page == "about", onClick = { page = "about" }, icon = { Icon(Icons.Default.Info, null) }, label = { Text("من نحن") })
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Brush.verticalGradient(listOf(Color(0xFF19130C), Bg, Color(0xFF100B0A))))) {
                Header(search, { search = it }, page !in listOf("team", "countryDetail", "about", "maker"))
                when (page) {
                    "home" -> HomeScreen(leagues, search, ::matches, onLeague = { selectedLeague = it; page = "league" }, onTeam = { l, t -> selectedLeague = l; selectedTeam = t; page = "team" })
                    "league" -> DetailListScreen("${selectedLeague?.icon.orEmpty()} ${selectedLeague?.name.orEmpty()}", "اختار الفريق لعرض الأطقم", selectedLeague?.teams.orEmpty().filter { matches(it.name, search) }, { it.name }, { it.logo }, onBack = { back() }, onClick = { selectedTeam = it; page = "team" })
                    "team" -> TeamScreen(selectedTeam, ::isFavorite, ::toggleFavorite, ::showUrl, clipboard::setText, onBack = { back() })
                    "countries" -> CountryScreen(countries, search, ::matches, onCountry = { selectedCountry = it; page = "countryDetail" })
                    "countryDetail" -> CountryDetailScreen(selectedCountry, ::isFavorite, ::toggleFavorite, ::showUrl, clipboard::setText, onBack = { back() }, onSub = { selectedCountry = it })
                    "dolabak" -> DolabakScreen(onFavorites = { page = "favorites" }, onMaker = { page = "maker" })
                    "favorites" -> FavoritesScreen(favorites, onBack = { back() }, onOpen = ::showUrl, onRemove = { toggleFavorite(it) })
                    "maker" -> MakerScreen(onBack = { back() }, onOpen = ::showUrl)
                    "about" -> AboutScreen(::showUrl)
                }
            }
        }
    }
}

@Composable private fun Header(search: String, onSearch: (String) -> Unit, visible: Boolean) {
    Column(Modifier.fillMaxWidth().background(Color(0xAA090909)).padding(horizontal = 14.dp, vertical = 10.dp)) {
        Text("دولابك لدريم 26", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 25.sp, fontWeight = FontWeight.Black, color = Gold)
        if (visible) OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true, placeholder = { Text("ابحث عن الأهلي أو الزمالك أو البرتغال...") }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(18.dp), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Gold, unfocusedBorderColor = Color.Gray, focusedContainerColor = Color.White.copy(.05f), unfocusedContainerColor = Color.White.copy(.04f)))
    }
}

@Composable private fun HomeScreen(leagues: List<League>, query: String, matches: (String, String) -> Boolean, onLeague: (League) -> Unit, onTeam: (League, Team) -> Unit) {
    val filtered = leagues.filter { matches(it.name, query) || it.teams.any { t -> matches(t.name, query) } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Hero("⚽ دولابك لدريم ⚽", "كل أطقم الأندية والمنتخبات في مكان واحد، مع إمكانية نسخ رابط كل صورة بضغطة واحدة.")
        SectionTitle("📰 الأخبار")
        listOf("جاري صنع تيشرت انتر ميلان 2026/27 بكل تفاصيل", "تم اضافة صنع صورة ولينك للصورة", "صنع طقم خاص بك في دريم ليج (قريباً)", "تطبيق دولابك لدريم", "اضافة الاطقم المميزة القديمة في المنتخبات").forEach { NewsCard(it) }
        SectionTitle("الدوريات")
        if (filtered.isEmpty()) EmptyState("مفيش نتيجة بالاسم ده. جرّب اسم تاني بالعربي أو بالإنجليزي.")
        GridCards(filtered, key = { it.id }, title = { "${it.icon} ${it.name}" }, subtitle = { "${it.teams.size} فريق" }, image = { "" }, onClick = onLeague)
        if (query.isNotBlank()) {
            val teamHits = leagues.flatMap { l -> l.teams.filter { matches(it.name, query) }.map { l to it } }
            if (teamHits.isNotEmpty()) { SectionTitle("نتائج الأندية") ; teamHits.forEach { (l,t) -> Text("${t.name} — ${l.name}", Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(12.dp)).background(Panel).clickable { onTeam(l,t) }.padding(16.dp), color = Color.White) } }
        }
    }
}

@Composable private fun CountryScreen(countries: List<Country>, query: String, matches: (String, String) -> Boolean, onCountry: (Country) -> Unit) {
    val filtered = countries.filter { matches(it.name, query) || it.subcountries.any { s -> matches(s.name, query) } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Hero("المنتخبات 🌍", "أطقم المنتخبات المتاحة.")
        GridCards(filtered, key = { it.name }, title = { "${it.flag} ${it.name}" }, subtitle = { if (it.subcountries.isNotEmpty()) "منتخبات مميزة" else "عرض الأطقم" }, image = { it.logo }, onClick = onCountry)
        if (filtered.isEmpty()) EmptyState("مفيش منتخب بالاسم ده")
    }
}

@Composable private fun TeamScreen(team: Team?, isFavorite: (String) -> Boolean, toggle: (Favorite) -> Unit, open: (String) -> Unit, copy: (androidx.compose.ui.text.AnnotatedString) -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        BackButton(onBack); Hero(team?.name ?: "الفريق", "اختار الطقم أو اللوجو لفتحه ونسخ رابطه.")
        team?.let { t ->
            if (t.logo.isNotBlank()) KitCard(Kit("اللوجو", t.logo), isFavorite, toggle, open, copy)
            t.kits.forEach { KitCard(it, isFavorite, toggle, open, copy) }
        }
    }
}

@Composable private fun CountryDetailScreen(country: Country?, isFavorite: (String) -> Boolean, toggle: (Favorite) -> Unit, open: (String) -> Unit, copy: (androidx.compose.ui.text.AnnotatedString) -> Unit, onBack: () -> Unit, onSub: (Country) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        BackButton(onBack); Hero("${country?.flag.orEmpty()} ${country?.name.orEmpty()}", "أطقم المنتخب المتاحة")
        country?.subcountries?.forEach { sub -> Text("${sub.flag} ${sub.name}  ←", Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(RoundedCornerShape(16.dp)).background(Panel).clickable { onSub(sub) }.padding(16.dp), color = Color.White, fontWeight = FontWeight.Bold) }
        country?.let { c -> if (c.logo.isNotBlank()) KitCard(Kit("اللوجو", c.logo), isFavorite, toggle, open, copy); c.kits.forEach { KitCard(it, isFavorite, toggle, open, copy) } }
    }
}

@Composable private fun KitCard(kit: Kit, isFavorite: (String) -> Boolean, toggle: (Favorite) -> Unit, open: (String) -> Unit, copy: (androidx.compose.ui.text.AnnotatedString) -> Unit) {
    val context = LocalContext.current
    Card(Modifier.fillMaxWidth().padding(vertical = 7.dp), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text(kit.name, Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp); Text(if (isFavorite(kit.url)) "⭐" else "☆", Modifier.clickable { toggle(Favorite(kit.name, kit.url)) }.padding(8.dp), color = Gold, fontSize = 24.sp) }
            AsyncImage(model = kit.url, contentDescription = kit.name, modifier = Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(14.dp)).clickable { open(kit.url) })
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { copy(androidx.compose.ui.text.AnnotatedString(kit.url)); Toast.makeText(context, "تم نسخ الرابط", Toast.LENGTH_SHORT).show() }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)) { Text("نسخ الرابط") }
                OutlinedButton(onClick = { val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, kit.url); context.startActivity(Intent.createChooser(send, "مشاركة رابط الصورة")) }, modifier = Modifier.weight(1f)) { Text("مشاركة") }
            }
        }
    }
}

@Composable private fun DetailListScreen(title: String, subtitle: String, items: List<Team>, name: (Team) -> String, image: (Team) -> String, onBack: () -> Unit, onClick: (Team) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) { BackButton(onBack); Hero(title, subtitle); items.forEach { t -> Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(16.dp)).background(Panel).clickable { onClick(t) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { if (image(t).isNotBlank()) AsyncImage(image(t), null, Modifier.size(58.dp)); Text(name(t), Modifier.weight(1f).padding(horizontal = 12.dp), color = Color.White, fontWeight = FontWeight.Bold); Text("عرض الأطقم ←", color = Gold) } } }
}

@Composable private fun DolabakScreen(onFavorites: () -> Unit, onMaker: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Hero("🗄️ دولابك", "كل اللوجوهات والأطقم اللي حفظتها في مكان واحد ⭐")
        FeatureCard("صناعة طقم في اللعبة من أي شركة", "أديداس / نايك / بوما — قريباً", "🪪")
        FeatureCard("صناعة بطاقتك", "صمّم بطاقتك الخاصة داخل دولابك — قريباً", "📲")
        ActionCard("⭐ المفضلة", "كل الأطقم واللوجوهات المحفوظة", onFavorites)
        ActionCard("🖼️ صنع اللينك والصورة", "تجهيز الصور بمقاس 512×512", onMaker)
    }
}

@Composable private fun FavoritesScreen(items: List<Favorite>, onBack: () -> Unit, onOpen: (String) -> Unit, onRemove: (Favorite) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) { BackButton(onBack); Hero("⭐ المفضلة", "كل الأطقم واللوجوهات اللي حفظتها."); if (items.isEmpty()) EmptyState("لسه مفيش مفضلات — اضغط على النجمة فوق أي طقم علشان تحفظه هنا.") else items.toList().forEach { f -> Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).clip(RoundedCornerShape(14.dp)).background(Panel).clickable { onOpen(f.url) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(f.name, Modifier.weight(1f), color = Color.White); Text("⭐", Modifier.clickable { onRemove(f) }, color = Gold) } } }
}

@Composable private fun MakerScreen(onBack: () -> Unit, onOpen: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) { BackButton(onBack); Hero("🖼️ صنع اللينك والصورة", "أداة تجهيز الصور 512×512 ورفعها للحصول على رابط مشاركة."); ActionCard("فتح موقع رفع الصور", "يمكنك رفع الصورة والحصول على رابط مباشر", { onOpen("https://up6.cc/") }); Text("ملاحظة: أداة تحويل الصور المدمجة في نسخة الموقع تحتاج إلى نقل مستقل إلى Android Native، ولم يتم استبدالها بأداة شكلية.", color = Muted, modifier = Modifier.padding(12.dp), lineHeight = 23.sp) }
}

@Composable private fun AboutScreen(open: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) { Hero("من نحن", "دولابك لدريم هو مكان مرتب لأطقم Dream League Soccer."); ActionCard("📢 جروب / قناة دولابك لدريم", "Telegram", { open("https://t.me/KitDlsStar") }); ActionCard("🔵 تليجرام", "التواصل الخاص", { open("https://t.me/Magnet1717") }); ActionCard("🟢 واتساب", "التواصل", { open("https://wa.me/201224244991") }) }
}

@Composable private fun <T> GridCards(entries: List<T>, key: (T) -> String, title: (T) -> String, subtitle: (T) -> String, image: (T) -> String, onClick: (T) -> Unit) {
    LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxWidth().heightIn(max = 5000.dp), userScrollEnabled = false, horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(entries, key = { key(it) }) { item -> Card(Modifier.fillMaxWidth().clickable { onClick(item) }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) { if (image(item).isNotBlank()) AsyncImage(image(item), null, Modifier.size(75.dp)); Text(title(item), color = Color.White, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center); Text(subtitle(item), color = Muted, fontSize = 12.sp) } } }
    }
}

@Composable private fun Hero(title: String, body: String) { Column(Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0x33FFD000), Color(0x22E53935), Panel))).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(title, color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center); Spacer(Modifier.height(8.dp)); Text(body, color = Muted, textAlign = TextAlign.Center, lineHeight = 22.sp) } }
@Composable private fun SectionTitle(text: String) { Text(text, Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 9.dp), color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
@Composable private fun NewsCard(text: String) { Text("✦  $text", Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(13.dp)).background(Panel).padding(13.dp), color = Color.White, fontSize = 14.sp) }
@Composable private fun BackButton(onClick: () -> Unit) { Text("← رجوع", Modifier.padding(bottom = 10.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF30251A)).clickable { onClick() }.padding(horizontal = 16.dp, vertical = 10.dp), color = Gold, fontWeight = FontWeight.Bold) }
@Composable private fun EmptyState(text: String) { Text(text, Modifier.fillMaxWidth().padding(22.dp), color = Muted, textAlign = TextAlign.Center) }
@Composable private fun FeatureCard(title: String, body: String, icon: String) { Card(Modifier.fillMaxWidth().padding(vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = Panel)) { Column(Modifier.padding(16.dp)) { Text("$icon  $title", color = Color.White, fontWeight = FontWeight.Bold); Text(body, color = Muted) } } }
@Composable private fun ActionCard(title: String, body: String, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(17.dp)) { Text(title, color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(body, color = Muted, modifier = Modifier.padding(top = 5.dp)) } } }
